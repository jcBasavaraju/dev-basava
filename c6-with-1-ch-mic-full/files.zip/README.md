# 1CH Mic Tester — ICS43434 Edition (v2 Fixed + Enhanced)

**Board:** Glyph C6 (ESP32-C6)
**Mic:** ICS43434  (WS=20, BCK=21, SD=18)
**Test tone:** Variable frequency (default 2000 Hz) via PC speaker
**Pass condition:** SNR ≥ 20 dB  +  peak frequency within ±200 Hz of test frequency

---

## Files

| File | Description |
|------|-------------|
| `mic_tester_firmware.ino` | Upload to Glyph C6 via Arduino IDE |
| `mic_tester_app.py` | Run on PC — v2: fixed graphs + frequency control |
| `install_and_run.bat` | Windows: installs deps + launches app |
| `install_and_run.sh` | Linux/macOS: installs deps + launches app |
| `README.md` | This file |

---

## What's Fixed in v2

### Bug Fix: Mic Graph Was Always Animated
**Root cause:** The original code used `sig_amp=0.85` as the idle default, so the mic waveform always showed a full-amplitude sine wave regardless of whether a mic was connected or a test was running. This made it impossible to visually tell if a mic was dead.

**Fix:** Proper state machine with three states:
- **IDLE** → Mic graph shows a flat line (tiny ambient noise only). Text overlay: `— IDLE — connect ESP32 and run a test —`
- **TESTING** → Mic graph shows low-level "listening" noise (mic is alive but we haven't analysed yet). Text overlay: `— LISTENING — recording in progress… —`
- **RESULT** → Mic graph shows amplitude mathematically scaled from the real `signal_db` value returned by firmware. Dead mic = tiny flat line. Good mic = strong sine wave.

---

## New: Signal Generator Control Panel

The top of the left column now has a full frequency generator UI:

| Control | Description |
|---------|-------------|
| **Frequency display** | Shows current Hz in large digits (updates live) |
| **Slider** | Drag from 20 Hz to 20 kHz — graph labels update instantly |
| **Preset buttons** | Quick jump: 250 / 500 / 1k / 2k / 4k / 8k Hz |
| **Custom entry** | Type any value (20–20000) and press Enter or Set |
| **Volume slider** | 0–100% output volume |
| **Preview Tone** | Play/stop the tone without running a full test |

The chosen frequency is used for both the PC tone output and the FFT pass/fail evaluation.

---

## Graph Panel (right side)

Three clearly labelled plots, all dark-themed, animate at ~20 fps:

### 1. ▶ SIGNAL GENERATOR — what we are sending
- Blue animated sine wave at the current test frequency
- Title updates dynamically when you change the frequency
- Time axis scales automatically to show ~4 cycles

### 2. 🎙 MIC CAPTURE — what the 1CH mic + ESP32 heard
- **IDLE:** flat line + grey text overlay (not a fake sine)
- **TESTING:** low-noise "listening" wiggle
- **AFTER TEST:** amplitude proportional to real `signal_db`. Dead mic stays flat. Good mic shows strong sine. Failed mic shows weak sine.
- Green annotation shows peak Hz + SNR after test

### 3. 📊 FFT SPECTRUM — frequency domain view
- Blue: generator signal peak at chosen frequency
- Green: mic captured signal (flat at idle, real after test)
- Red dashed: noise floor level
- Annotation shows peak frequency and SNR verdict

---

## Firmware Setup (Arduino IDE)

### Required libraries (install via Library Manager)
- **ESP32-audioI2S** by schreibfaul1
- **arduinoFFT** by kosme

### Board settings
- Board: ESP32C6 Dev Module
- Upload speed: 921600
- USB CDC on Boot: Enabled  ← **important**

### Upload steps
1. Open `mic_tester_firmware.ino` in Arduino IDE
2. Select the correct COM port
3. Click Upload
4. Open Serial Monitor at 115200 baud — you should see:
   `{"status":"READY","msg":"ICS43434 mic tester ready"}`

---

## PC App Setup

```
pip install pyserial sounddevice numpy matplotlib mysql-connector-python
```

Or double-click `install_and_run.bat` (Windows) / `./install_and_run.sh` (Linux/macOS).

---

## How to Test

1. **Set frequency** — use the slider or preset buttons (default 2000 Hz is fine)
2. **Preview (optional)** — click Preview Tone to hear what you'll be playing
3. **Connect** — select the Glyph C6 COM port, click Connect
4. **Enter** the mic serial number
5. **Place** the mic PCB near the laptop speaker (5–15 cm)
6. **Press** Start Test
7. **Watch** — mic graph goes from flat → listening noise → real signal after result
8. **Result** shown as PASS or FAIL with SNR, peak freq, signal level, noise floor
9. Serial number clears automatically — scan the next mic and repeat

---

## Fail Reasons Explained

| Reason | Likely cause |
|--------|--------------|
| Signal indistinguishable from noise | Dead mic, broken solder joint |
| Very low SNR < 5 dB | Open circuit, dead mic |
| Low SNR 5–12 dB | Mic too weak, blocked path, low volume |
| Marginal SNR 12–20 dB | Check placement, increase speaker volume |
| Peak at wrong frequency | I2S clock error, EMI |
| High noise floor > −20 dB | EMI, noisy power supply |

---

## MySQL Storage (optional)

Fill in connection fields and click **Connect DB**. Table auto-created:

```sql
id, serial_number, test_time, snr_db, peak_freq_hz,
signal_db, noise_db, result, fail_reason
```

---

## ICS43434 Technical Notes

- **Format:** LEFT-JUSTIFIED (not standard I2S)
- **Bit depth:** 24-bit data in top 24 bits of 32-bit word
- **Normalisation:** samples shifted right 8, divided by 0x7FFFFF
